import React,{useState} from 'react'
import { useDispatch } from 'react-redux';
import { login } from '../../redux/apiCall';

export default function Login() {
    const [username,setUsername] = useState("");
    const [password,setPassword] = useState("");
    const dispatch = useDispatch();

    const handleClick = (e) => {
        e.preventDefault();
        login(dispatch, {username, password});
    }

    return (
    <div style={{
        display:'flex',
        justifyContent:"center",
        alignItems: "center",
        flexDirection:"column",
        height: "100vh",
    }}>
        <input
            style={{
                padding: 10,
                marginBottom: 20,
                borderRadius:5
            }} 
            type="text"
            placeholder='username'
            onChange={(e)=>setUsername(e.target.value)} 
        />
        <input
            style={{
                padding: 10,
                marginBottom: 20,
                borderRadius:5
            }} 
            type="password"
            placeholder='password'
            onChange={(e)=>setPassword(e.target.value)} 
        />
        <button
            style={{
                padding: 5,
                width: 70,
                fontSize: 16,
                color:"white",
                backgroundColor: "green",
                borderRadius: 5
            }}
            onClick={handleClick}>Login</button>
    </div>
  )
}
