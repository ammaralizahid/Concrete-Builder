import { initializeApp } from "firebase/app";
const firebaseConfig = {
  apiKey: process.env.API_KEY,
  authDomain: "shop-6f562.firebaseapp.com",
  projectId: "shop-6f562",
  storageBucket: "shop-6f562.appspot.com",
  messagingSenderId: "565330065005",
  appId: "1:565330065005:web:00041d4706528eb55a3164"
};

const app = initializeApp(firebaseConfig);

export default app;