import React from "react";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";

import Input from "components/input";
import Button from "components/button";

import { apiRequest } from "utils/helper";

import style from "./forgot-password.module.scss";

const ForgotPassword = () => {
  const navigate = useNavigate();

  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = async (data) => {
    console.log(data);
    const res = await apiRequest({
      method: "post",
      url: "auth/forgot-password/",
      body: {
        ...data,
      },
    });
    console.log(res);
    if (res.status === 200 || res.status === 201) {
      navigate("/login");
    }
  };

  return (
    <>
      <div className={style.main_wrapper}>
        <div className={style.card_wrapper}>
          <div className={style.card_header}>
            <h2>Forget Password</h2>
          </div>
          <div className={style.form_wrapper}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <Input
                label="Enter you email and we’ll send the instructions."
                name="email"
                placeholder={"Your email"}
                register={register}
                errorMessage={errors?.email?.message}
              />
              <div className={style.btn_wrapper}>
                <Button
                  type={"submit"}
                  text={"Send reset instructions"}
                  btnClass={style.btnLogin}
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;

export const schema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .email("Please enter valid email"),
});
