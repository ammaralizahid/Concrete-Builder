import React from "react";
import { Link } from "react-router-dom";

import Input from "components/input";
import Button from "components/button";

import { LoginHelper } from "./login-helper";

import style from "./login.module.scss";

const Login = () => {
  const { onSubmit, handleSubmit, register, navigate, isLoading, errors } =
    LoginHelper();

  return (
    <>
      <div className={style.main_wrapper}>
        <div className={style.card_wrapper}>
          <div className={style.card_header}>
            <h2>Welcome back!</h2>
            <p>Log in to access your dashboard.</p>
          </div>
          <div className={style.form_wrapper}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <Input
                label="Email"
                name="email"
                className={style.textField}
                register={register}
                errorMessage={errors?.email?.message}
              />

              <Input
                label="Password"
                type="password"
                name="password"
                className={style.textField}
                register={register}
                errorMessage={errors?.password?.message}
              />
              <div className={style.form_footer}>
                <p>
                  Don't have an account? <Link to={"/sign-up"}>Sign up</Link>
                </p>
                <div className={style.btn_wrapper}>
                  <Button
                    type={"submit"}
                    text={"Log in"}
                    isLoading={isLoading}
                    btnClass={style.btnLogin}
                  />
                  <Button
                    type={"button"}
                    text={"Forgot Password?"}
                    handleClick={() => navigate("/forgot-password")}
                    btnClass={style.btnForgot}
                  />
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
