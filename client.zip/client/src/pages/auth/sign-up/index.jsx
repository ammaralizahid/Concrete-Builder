import React from "react";
import { Link } from "react-router-dom";

import Input from "components/input";
import Button from "components/button";

import { SignUpHelper } from "./signup-helper";

import style from "./signup.module.scss";

const SignUp = () => {
  const { onSubmit, handleSubmit, isLoading, register, errors } =
    SignUpHelper();
  return (
    <>
      <div className={style.main_wrapper}>
        <div className={style.card_wrapper}>
          <div className={style.card_header}>
            <h2>Create a New Account</h2>
            <p>Welcome to ConcreteAI Dashboard!</p>
          </div>
          <div className={style.form_wrapper}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <Input
                label="First Name"
                name="firstName"
                register={register}
                className={style.textField}
                errorMessage={errors?.firstName?.message}
              />
              <Input
                label="Last Name"
                name="lastName"
                register={register}
                className={style.textField}
                errorMessage={errors?.lastName?.message}
              />
              <Input
                label="Email"
                name="email"
                register={register}
                className={style.textField}
                errorMessage={errors?.email?.message}
              />
              <Input
                label="Password"
                type="password"
                name="password"
                className={style.textField}
                register={register}
                errorMessage={errors?.password?.message}
              />
              <div className={style.form_footer}>
                <p>
                  <input type={"checkbox"} style={{ marginRight: "10px" }} />I
                  agree to the <Link to={"d"}>Terms and Conditions</Link>
                </p>
                <div className={style.btn_wrapper}>
                  <Button
                    type={"submit"}
                    text={"Sign Up"}
                    isLoading={isLoading}
                    btnClass={style.btnLogin}
                  />
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignUp;
