import { useState } from "react";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { signUp } from "api-services/auth";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";

export const SignUpHelper = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(signUpSchema),
  });

  const onSubmit = async (data) => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(true);
    }, 2000);
    signUp({ data, navigate, setIsLoading });
  };

  return {
    onSubmit,
    handleSubmit,
    register,
    isLoading,
    errors,
  };
};

export const signUpSchema = yup.object().shape({
  firstName: yup.string().required("First name is required"),
  lastName: yup.string().required("Last name is required"),
  email: yup
    .string()
    .required("Email is required")
    .email("Please enter valid email"),
  password: yup
    .string()
    .required("Password is required")
    .min(8, "Password should be 8 character"),
});
