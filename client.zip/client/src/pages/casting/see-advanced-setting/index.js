import React, { useState } from "react";

import Modal from "components/modal";

import style from "./advance-setting.module.scss";
import Input from "components/input";
import Select from "components/select";
import arrow from "assets/chevron_down.svg";
import Button from "components/button";
import CreatedSuccessModal from "components/created-successfully-modal";
import UnderlineInput from "components/underline-input";
import TextArea from "components/textarea";

const SeeAdvancedSettings = ({
  openAdvanceSetting,
  setOpenAdvanceSetting,
  setOpenCastModal,
}) => {
  const [successModalOpen, setSuccessModalOpen] = useState(false);

  return (
    <>
      <Modal
        open={openAdvanceSetting}
        className={style.wrapperClass}
        handleClose={() => setOpenAdvanceSetting(false)}
      >
        <div className={style.headingClass}>
          <h2>New Cast</h2>
        </div>
        <div className={style.mainDiv}>
          <div className={style.leftSide}>
            <div style={{ padding: "0px 23px" }}>
              <div style={{ marginTop: "15px" }}>
                <Input label="Cast Name *" placeholder={"LVL 11-Phase 2"} />
              </div>
              <div style={{ marginTop: "15px" }}>
                <TextArea label="Remarks" name={"remarks"} />
              </div>
              <div style={{ marginTop: "15px" }}>
                <Select
                  label="Concrete Information *"
                  placeholder={"Pan-United G40/50"}
                >
                  {options?.map((ele, index) => (
                    <option key={index} value={ele?.value}>
                      {ele?.label}
                    </option>
                  ))}
                </Select>
              </div>
            </div>

            <div className={style.footerDiv}>
              <p>See Advanced Settings</p>
              <img src={arrow} alt="" />
            </div>
          </div>
          <div className={style.rightSide}>
            <UnderlineInput
              label="Concrete Supplier *"
              placeholder="Pan United"
            />
            <UnderlineInput label="Concrete Type *" placeholder="G40/50" />
            <UnderlineInput label="Portland" unit="Kg/m3" />
            <UnderlineInput label="Coarse Aggregate" unit="Kg/m3" />
            <UnderlineInput label="Fly Ash" unit="Kg/m3" />
            <UnderlineInput label="Retarding Mixture" unit="Kg/m3" />
            <UnderlineInput label="Water" unit="Kg/m3" />
            <UnderlineInput label="Fine Aggrate" unit="Kg/m3" />
            <UnderlineInput label="Accelerating Admixture" unit="Kg/m3" />
            <UnderlineInput label="Concrete Grade *" unit="Number" />
            <UnderlineInput label="Q *" unit="Number" />{" "}
            <UnderlineInput label="RT *" unit="Number" />{" "}
            <UnderlineInput label="Su *" unit="Number" />{" "}
            <UnderlineInput label="K *" unit="Number" />{" "}
            <UnderlineInput label="MO *" unit="Number" />
            <UnderlineInput label="Offset *" unit="Number" />
          </div>
        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            width: "100%",
            justifyContent: "flex-end",
            padding: "17px 25px",
          }}
        >
          <p className={style.p} onClick={() => setOpenAdvanceSetting(false)}>
            Cancel
          </p>
          <Button
            text="Create"
            handleClick={() => {
              setSuccessModalOpen(true);
              setOpenAdvanceSetting(false);
              setOpenCastModal(false);
            }}
          />
        </div>
      </Modal>
      <CreatedSuccessModal
        successModalOpen={successModalOpen}
        setSuccessModalOpen={setSuccessModalOpen}
      />
    </>
  );
};

export default SeeAdvancedSettings;

const options = [
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
];
