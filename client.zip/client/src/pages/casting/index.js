/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import Table from "components/table";
import Input from "components/input";
import Button from "components/button";
import AddEditCastModal from "./add-edit-cast-modal";

import { setLogout } from "store";

import { apiRequest } from "utils/helper";
import { store, setCastList } from "store";
import { fetchCastList } from "api-services/casting";

import edit from "assets/icons/pencil-icon.svg";
import search from "assets/search.png";
import style from "./casting.module.scss";
import { columns } from "./helper";

const Home = () => {
  const navigate = useNavigate();

  const [projectName, setProjectName] = useState("");
  const [castingData, setCastingData] = useState({});
  const [singleCastData, setSingleCastData] = useState({});
  const [openCastModal, setOpenCastModal] = useState(false);
  const [editProjectName, setEditProjectName] = useState(false);

  const handleSaveClick = async () => {
    const res = await apiRequest({
      method: "put",
      url: "projects",
      body: { id: castingData?._id, projectName: projectName },
    });
    console.log(res);
    setEditProjectName(false);
  };

  const handleEdit = (row) => {
    setOpenCastModal(true);
    setSingleCastData({ ...row });
  };

  const fetchCastingList = async () => {
    const res = await fetchCastList();
    if (res !== "Unauthorized") {
      setCastingData({ ...res?.data?.project });
      setProjectName(res.data.project.projectName);
      store.dispatch(setCastList(res.data.project.castings));
    } else {
      store.dispatch(setLogout(""));
      navigate("/login");
    }
  };

  useEffect(() => {
    fetchCastingList();
  }, []);

  return (
    <>
      <div className={style.mainClass}>
        <div className={style.flexClass}>
          <div className={style.leftClass}>
            {editProjectName ? (
              <Input
                placeholder="project"
                value={projectName}
                inputClass={style.castNameInp}
                onChange={(e) => setProjectName(e.target.value)}
              />
            ) : (
              <h6>{projectName || "--"}</h6>
            )}
            <div style={{ display: "flex", alignItems: "center" }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  borderBottom: "1px solid #9ea0a5",
                  marginLeft: "15px",
                }}
              >
                {!editProjectName ? (
                  <p
                    onClick={() => setEditProjectName(true)}
                    style={{ cursor: "pointer" }}
                  >
                    Edit
                  </p>
                ) : (
                  <p onClick={handleSaveClick} style={{ cursor: "pointer" }}>
                    Save
                  </p>
                )}
                {!editProjectName && (
                  <img
                    src={edit}
                    alt=""
                    onClick={() => setEditProjectName(true)}
                  />
                )}
              </div>
              <div className={style.castingBtn}>
                <p>{castingData?.castings?.length} Casts</p>
              </div>
              <div className={style.castingBtn}>
                <p>0 Devices</p>
              </div>
            </div>
          </div>
          <div className={style.right}>
            <Input placeholder="Search" icon={search} />
            <Button
              text="New Cast"
              handleClick={() => setOpenCastModal(true)}
            />
          </div>
        </div>
        <Table
          rows={castingData?.castings}
          columns={columns}
          minWidth="1400px"
          handleEdit={handleEdit}
          tableHeight={style.tableHeight}
          deleteApiUrl="projects/castings"
          fetchTableList={fetchCastingList}
        />
      </div>
      <AddEditCastModal
        openCastModal={openCastModal}
        setOpenCastModal={setOpenCastModal}
        fetchCastingList={fetchCastingList}
        singleCastData={singleCastData}
        setSingleCastData={setSingleCastData}
      />
    </>
  );
};

export default Home;
