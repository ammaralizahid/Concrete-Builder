export const columns = [
  {
    key: "castName",
    name: "Casts.",
    width: "50px",
  },

  {
    key: "structure",
    name: "Structure",
    width: "50px",
  },
  {
    key: "device",
    name: "Device",
    width: "50px",
  },

  {
    key: "remarks",
    name: " Remarks",
    width: "100px",
  },

  {
    key: "actions",
    name: "",
    width: "100px",
  },
];
