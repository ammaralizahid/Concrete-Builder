/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Modal from "components/modal";
import Input from "components/input";
import TextArea from "components/textarea";
import Select from "components/select";
import arrow from "assets/chevron_down.svg";
import Button from "components/button";
import CreatedSuccessModal from "components/created-successfully-modal";
import SeeAdvancedSettings from "../see-advanced-setting";
import { castingAddSchema } from "./helper";
import { apiRequest } from "utils/helper";

import style from "./add-edit.module.scss";

const AddEditCastModal = ({
  openCastModal,
  setOpenCastModal,
  fetchCastingList,
  singleCastData,
  setSingleCastData,
}) => {
  const [successModalOpen, setSuccessModalOpen] = useState(false);
  const [openAdvanceSetting, setOpenAdvanceSetting] = useState(false);
  const [loading, setLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(castingAddSchema),
  });

  const onSubmit = async (data) => {
    console.log(data);
    !data?.remarks && delete data["remarks"];
    data.advanceSetting = openAdvanceSetting;
    console.log(data);

    setLoading(true);

    const res = await apiRequest({
      method: singleCastData?._id ? "put" : "post",
      url: "projects/castings",
      body: {
        ...data,
        ...(singleCastData?._id && { id: singleCastData?._id }),
      },
    });
    if (res.status === 200 || res.status === 201) {
      fetchCastingList();
      handleClose();
    }
    setLoading(false);
  };

  const handleClose = () => {
    setOpenCastModal(false);
    Object?.keys(singleCastData)?.length && setSingleCastData({});
    reset({});
  };

  useEffect(() => {
    if (Object?.keys(singleCastData)?.length)
      reset({
        remarks: singleCastData?.remarks,
        concreteInformation: singleCastData?.concreteInformation,
        castName: singleCastData?.castName,
      });
  }, [singleCastData]);

  return (
    <>
      <Modal
        open={openCastModal}
        className={style.wrapperClass}
        handleClose={handleClose}
      >
        <div className={style.headingClass}>
          <h2>New Cast</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div style={{ marginTop: "15px" }}>
            <Input
              label="Cast Name*"
              name={"castName"}
              register={register}
              errorMessage={errors?.castName?.message}
            />
          </div>
          <div style={{ marginTop: "15px" }}>
            <TextArea
              label="Remarks"
              name={"remarks"}
              register={register}
              errorMessage={errors?.remarks?.message}
            />
          </div>
          <div style={{ marginTop: "15px" }}>
            <Select
              label="Concrete Information*"
              name={"concreteInformation"}
              register={register}
              errorMessage={errors?.concreteInformation?.message}
            >
              <option value="">select</option>
              {options?.map((ele, index) => (
                <option key={index} value={ele?.value}>
                  {ele?.label}
                </option>
              ))}
            </Select>
          </div>

          <div
            className={style.footerDiv}
            onClick={() => setOpenAdvanceSetting(true)}
          >
            <p>See Advanced Settings</p>
            <img src={arrow} alt="" />
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              width: "100%",
              justifyContent: "flex-end",
              marginTop: "20px",
            }}
          >
            <p className={style.p} onClick={handleClose}>
              Cancel
            </p>
            <Button text="Create" isLoading={loading} />
          </div>
        </form>
      </Modal>
      <CreatedSuccessModal
        successModalOpen={successModalOpen}
        setSuccessModalOpen={setSuccessModalOpen}
      />
      <SeeAdvancedSettings
        setOpenAdvanceSetting={setOpenAdvanceSetting}
        openAdvanceSetting={openAdvanceSetting}
        setOpenCastModal={setOpenCastModal}
      />
    </>
  );
};

export default AddEditCastModal;

const options = [
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
];
