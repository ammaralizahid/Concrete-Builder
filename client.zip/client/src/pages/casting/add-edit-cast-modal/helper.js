import * as yup from "yup";

export const castingAddSchema = yup.object().shape({
  castName: yup.string().required("Cast name is required"),
  concreteInformation: yup
    .string()
    .required("Concrete information is required"),
});
