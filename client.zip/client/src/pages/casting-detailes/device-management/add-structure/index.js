/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Modal from "components/modal";
import Input from "components/input";
import Button from "components/button";
import TextArea from "components/textarea";

import { castingAddSchema } from "./helper";

import delete_icon from "assets/icons/delete-icon.svg";
import plus from "assets/plus.svg";

import style from "./add-edit.module.scss";
import Checkbox from "components/checkbox";
import Select from "components/select";

const AddStructure = ({
  openCastModal,
  setOpenCastModal,
  fetchCastingList,
  singleCastData,
  setSingleCastData,
}) => {
  const [loading, setLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(castingAddSchema),
  });

  const onSubmit = async (data) => {
    setLoading(false);
  };
  const handleClose = () => {
    setOpenCastModal(false);
    // reset({});
  };

  return (
    <>
      <Modal
        open={openCastModal}
        className={style.wrapperClass}
        handleClose={handleClose}
      >
        <div className={style.headingClass}>
          <h2>New Structure</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className={style.form}>
          <Input
            label="Cast Name"
            placeholder={"LVL 11 - Phase 2"}
            name={"castName"}
            register={register}
            className={style.field}
            errorMessage={errors?.castName?.message}
          />

          <Input
            label="Concrete Information"
            placeholder={"Pan-United G40/50"}
            name={"concrete_information"}
            register={register}
            className={style.field}
            errorMessage={errors?.castName?.message}
          />

          <Input
            label="Structure"
            name={"structure"}
            placeholder={"11HPB2"}
            className={style.field}
            register={register}
            errorMessage={errors?.castName?.message}
          />
          <div className={style.grid}>
            <div>
              <h6 className={style.h6}>Start Monitoring</h6>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Input
                  className={style.innerField}
                  name={"start"}
                  placeholder="12 June,2021"
                />
                <Input name={"start"} placeholder="1:00 PM" />
              </div>
            </div>
            <div>
              <h6 className={style.h6}>End Monitoring</h6>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Input
                  className={style.innerField}
                  name={"start"}
                  placeholder="12 June,2021"
                />
                <Input name={"start"} placeholder="1:00 PM" />
              </div>
            </div>
          </div>

          <TextArea
            label="Remarks"
            name={"remarks"}
            register={register}
            placeholder={
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit...."
            }
            className={style.field}
            errorMessage={errors?.remarks?.message}
          />

          <Input
            label="Device ID"
            name={"device_ID"}
            register={register}
            placeholder="A007"
            className={style.field}
            errorMessage={errors?.castName?.message}
          />
          <div className={style.tableDiv}>
            <table>
              <tr>
                <th></th>
                <th>Datapoint</th>
                <th>Remarks</th>
                <th></th>
              </tr>
              <tr>
                <th>
                  <Checkbox className={style.checkbox} />
                </th>
                <td>1</td>
                <td>Top</td>
                <td className={style.drop}>Drop Pin</td>
              </tr>
              <tr>
                <th>
                  <Checkbox className={style.checkbox} />
                </th>
                <td>1</td>
                <td>Top</td>
                <td className={style.drop}>Drop Pin</td>
              </tr>
            </table>
          </div>

          <div className={style.addDevice}>
            <div>
              <img src={plus} alt="" />
            </div>
            <p>Add new device</p>
          </div>

          <div>
            <div className={style.flexClass}>
              <div className={style.innerField}>
                <h6 style={{ marginTop: "0px" }} className={style.h6}>
                  Targets
                </h6>
                <Select name={"start"} placeholder="12 June,2021" />
              </div>
              <div className={style.innerDiv}>
                <p style={{ borderRight: "1px solid #d8d8d8 " }}>20</p>
                <p>MPa</p>
              </div>
            </div>
            <div className={style.flexClass} style={{ marginTop: "10px" }}>
              <div className={style.innerField}>
                <Select name={"start"} placeholder="12 June,2021" />
              </div>
              <div className={style.innerDiv}>
                <p style={{ borderRight: "1px solid #d8d8d8 " }}>20</p>
                <p>MPa</p>
              </div>
            </div>
          </div>
          <div className={style.addDevice}>
            <div>
              <img src={plus} alt="" />
            </div>
            <p>Add new taget</p>
          </div>

          <div className={style.btnFooterDiv}>
            <Button
              text="Delete Structure"
              isLoading={loading}
              btnClass={style.btn_delete}
              icon={delete_icon}
            />
            <div style={{ display: "flex", alignItems: "center" }}>
              <p className={style.p} onClick={handleClose}>
                Cancel
              </p>
              <Button
                text="Done"
                isLoading={loading}
                btnClass={style.btn_done}
              />
            </div>
          </div>
        </form>
      </Modal>
    </>
  );
};

export default AddStructure;
