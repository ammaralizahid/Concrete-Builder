/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Modal from "components/modal";
import Input from "components/input";

import style from "./stop-model.module.scss";
import Button from "components/button";

const StopModel = ({ openStopModel, setOpenStopModel }) => {
  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data) => {};
  const handleClose = () => {
    setOpenStopModel(false);
  };

  return (
    <>
      <Modal
        open={openStopModel}
        className={style.wrapperClass}
        handleClose={handleClose}
      >
        <form onSubmit={handleSubmit(onSubmit)}>
          <h3>11HPB2</h3>
          <div className={style.flex}>
            <h6>Start</h6>
            <Input
              name={"date"}
              placeholder={"12 Jun 2022 "}
              className={style.field}
              register={register}
              errorMessage={errors?.date?.message}
            />
            <Input
              name={"time"}
              placeholder={"8:00PM"}
              className={style.field}
              register={register}
              errorMessage={errors?.time?.message}
            />
          </div>
          <div className={style.flex}>
            <h6>Stop</h6>
            <Input
              name={"date"}
              placeholder={"12 Jun 2022 "}
              className={style.field}
              register={register}
              errorMessage={errors?.date?.message}
            />
            <Input
              name={"time"}
              placeholder={"8:00PM"}
              className={style.field}
              register={register}
              errorMessage={errors?.time?.message}
            />
          </div>
          <div className={style.btnDiv}>
            <p onClick={handleClose}>Cancel</p>
            <Button text={"Start"} />
          </div>
        </form>
      </Modal>
    </>
  );
};

export default StopModel;
