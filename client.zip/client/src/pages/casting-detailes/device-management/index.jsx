import React, { useState } from "react";
import Add from "assets/icons/plus.svg";
import style from "./device-management.module.scss";

import Button from "components/button";
import AddStructure from "./add-structure";
import DeviceTable from "./device-management-table";

const DeviceManagement = () => {
  const [openCastModal, setOpenCastModal] = useState(false);

  return (
    <div>
      <div className={style.info_wrapper}>
        <h3>Lvl 11 - Phase 2</h3>
        <Button
          text="Add Structure"
          icon={Add}
          handleClick={() => setOpenCastModal(true)}
        />
      </div>
      <DeviceTable
        openCastModal={openCastModal}
        setOpenCastModal={setOpenCastModal}
      />
      <AddStructure
        openCastModal={openCastModal}
        setOpenCastModal={setOpenCastModal}
      />
    </div>
  );
};

export default DeviceManagement;
