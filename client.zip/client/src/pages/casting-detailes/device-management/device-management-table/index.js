import React, { useState } from "react";

import Accordion from "components/accordion";
import Button from "components/button";

import icon from "assets/Vector.png";
import arrow from "assets/chevron_down.png";

import style from "./table.module.scss";
import StartModel from "../start-model";

const DeviceTable = ({ openCastModal, setOpenCastModal }) => {
  const [openStartModel, setOpenStartModel] = useState(true);
  const [openStopModel, setOpenStopModel] = useState(false);

  return (
    <>
      <div className={style.grid}>
        <div className={style.leftDiv}>
          <div className={style.headerDiv}>
            <div style={{ display: "flex", alignItems: "center" }}>
              <p>
                Structure
                <img src={icon} alt="" />
              </p>
              <p>
                Design Strength
                <img src={icon} alt="" />
              </p>
              <p>
                Remarks
                <img src={icon} alt="" />
              </p>
              <p>
                Casting date
                <img src={icon} alt="" />
              </p>
            </div>
            <Button text={"Expand All"} icon={arrow} />
          </div>
          <div style={{ padding: "20px 20px" }}>
            <Accordion
              openCastModal={openCastModal}
              setOpenCastModal={setOpenCastModal}
              openStartModel={openStartModel}
              setOpenStartModel={setOpenStartModel}
            />
          </div>
        </div>
        <div>
          <p>kk</p>
        </div>
      </div>
      <StartModel
        openStartModel={openStartModel}
        setOpenStartModel={setOpenStartModel}
        openStopModel={openStopModel}
        setOpenStopModel={setOpenStopModel}
      />
    </>
  );
};

export default DeviceTable;
