import React from "react";

const StructureManagement = () => {
  return <div>StructureManagement</div>;
};

export default StructureManagement;
