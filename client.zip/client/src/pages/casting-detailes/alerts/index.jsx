import React from "react";

const AlertManagement = () => {
  return <div>AlertManagement</div>;
};

export default AlertManagement;
