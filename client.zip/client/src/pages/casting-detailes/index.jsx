import React, { useState } from "react";

import style from "./casting-details.module.scss";
import DeviceManagement from "./device-management";
import StructureManagement from "./structures/index";
import AlertManagement from "./alerts";

const CastingDetails = () => {
  const [active, setActive] = useState(0);

  return (
    <>
      <div className={style.mainClass}>
        <div className={style.tab_wrapper}>
          <p
            onClick={() => setActive(0)}
            className={active === 0 ? style.active : ""}
          >
            Device Management
          </p>
          <p
            onClick={() => setActive(1)}
            className={active === 1 ? style.active : ""}
          >
            Structures
          </p>
          <p
            onClick={() => setActive(2)}
            className={active === 2 ? style.active : ""}
          >
            Alerts
          </p>
        </div>
      </div>
      {active === 0 && <DeviceManagement />}
      {active === 1 && <StructureManagement />}
      {active === 2 && <AlertManagement />}
    </>
  );
};

export default CastingDetails;
