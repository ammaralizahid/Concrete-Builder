export const columns = [
  {
    key: "concrete_supplier",
    name: "Concrete Supplier",
    width: "50px",
  },

  {
    key: "concrete_type",
    name: "Concrete Type",
    width: "50px",
  },
  {
    key: "create_date",
    name: "Concrete Date",
    width: "50px",
  },

  {
    key: "create_by",
    name: "Create By",
    width: "100px",
  },
  {
    key: "modified_date",
    name: "Modified Date",
    width: "100px",
  },
  {
    key: "modified_by",
    name: "Modified By",
    width: "100px",
  },
  {
    key: "remarks",
    name: "Remarks",
    width: "100px",
  },

  {
    key: "actions",
    name: "",
    width: "100px",
  },
];
