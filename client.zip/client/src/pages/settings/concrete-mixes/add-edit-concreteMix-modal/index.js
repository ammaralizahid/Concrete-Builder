/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Modal from "components/modal";
import Input from "components/input";
import TextArea from "components/textarea";
import Select from "components/select";
import arrow from "assets/chevron_down.svg";
import Button from "components/button";
import { castingAddSchema } from "./helper";
import { apiRequest } from "utils/helper";

import style from "./add-edit.module.scss";
import UnderlineInput from "components/underline-input";

const AddEditConcreteMix = ({
  openCastModal,
  setOpenCastModal,
  fetchCastingList,
  singleCastData,
  setSingleCastData,
}) => {
  const [successModalOpen, setSuccessModalOpen] = useState(false);
  const [openAdvanceSetting, setOpenAdvanceSetting] = useState(false);
  const [loading, setLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(castingAddSchema),
  });

  const onSubmit = async (data) => {
    console.log(data);
    !data?.remarks && delete data["remarks"];
    data.advanceSetting = openAdvanceSetting;
    console.log(data);

    setLoading(true);

    const res = await apiRequest({
      method: singleCastData?._id ? "put" : "post",
      url: "projects/castings",
      body: {
        ...data,
        ...(singleCastData?._id && { id: singleCastData?._id }),
      },
    });
    if (res.status === 200 || res.status === 201) {
      fetchCastingList();
      handleClose();
    }
    setLoading(false);
  };

  const handleClose = () => {
    setOpenCastModal(false);
    Object?.keys(singleCastData)?.length && setSingleCastData({});
    reset({});
  };

  useEffect(() => {
    if (Object?.keys(singleCastData)?.length)
      reset({
        remarks: singleCastData?.remarks,
        concreteInformation: singleCastData?.concreteInformation,
        castName: singleCastData?.castName,
      });
  }, [singleCastData]);

  return (
    <>
      <Modal
        open={openCastModal}
        className={style.wrapperClass}
        handleClose={handleClose}
      >
        <div className={style.headingClass}>
          <h2>Concrete Mix information</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className={style.formWrapper}>
            <UnderlineInput
              label="Concrete Supplier *"
              placeholder="Pan United"
            />
            <UnderlineInput label="Concrete Type *" placeholder="G40/50" />
            <UnderlineInput label="Portland" unit="Kg/m3" />
            <UnderlineInput label="Coarse Aggregate" unit="Kg/m3" />
            <UnderlineInput label="Fly Ash" unit="Kg/m3" />
            <UnderlineInput label="Retarding Mixture" unit="Kg/m3" />
            <UnderlineInput label="Water" unit="Kg/m3" />
            <UnderlineInput label="Fine Aggrate" unit="Kg/m3" />
            <UnderlineInput label="Accelerating Admixture" unit="Kg/m3" />
            <UnderlineInput label="Concrete Grade *" unit="Number" />
            <UnderlineInput label="Q *" unit="Number" />{" "}
            <UnderlineInput label="RT *" unit="Number" />{" "}
            <UnderlineInput label="Su *" unit="Number" />{" "}
            <UnderlineInput label="K *" unit="Number" />{" "}
            <UnderlineInput label="MO *" unit="Number" />
            <UnderlineInput label="Offset *" unit="Number" />
          </div>
          <TextArea label={"Remarks"} />
          <div
            style={{
              display: "flex",
              alignItems: "center",
              width: "100%",
              justifyContent: "flex-end",
              marginTop: "20px",
            }}
          >
            <p className={style.p} onClick={handleClose}>
              Cancel
            </p>
            <Button text="Create" isLoading={loading} />
          </div>
        </form>
      </Modal>
    </>
  );
};

export default AddEditConcreteMix;

const options = [
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
  {
    value: "Pan-United G40/50",
    label: "Pan-United G40/50",
  },
];
