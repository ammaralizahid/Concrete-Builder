/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Button from "components/button";
import Input from "components/input";

import { passwordUpdateSchema } from "./helper";

import style from "./password.module.scss";

const PasswordSecurity = () => {
  const [loading, setLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(passwordUpdateSchema),
  });

  const onSubmit = async (data) => {
    console.log(data);
  };

  return (
    <>
      <div className={style.wrapperClass}>
        <div className={style.headingClass}>
          <h2>Notification</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className={style.formWrapper}>
          <div style={{ marginTop: "20px" }}>
            <Input
              label={"Current Password"}
              name={"current_password"}
              register={register}
              errorMessage={errors?.current_password?.message}
            />
          </div>
          <div style={{ marginTop: "20px" }}>
            <Input
              label={"New Password"}
              name={"new_password"}
              register={register}
              errorMessage={errors?.new_password?.message}
            />
          </div>
          <div style={{ marginTop: "20px" }}>
            <Input
              label={"Re-Type New Password"}
              name={"retype_password"}
              register={register}
              errorMessage={errors?.retype_password?.message}
            />
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              width: "100%",
              justifyContent: "flex-end",
              marginTop: "30px",
            }}
          >
            <Button
              text="Save"
              type={"submit"}
              btnClass={style.btnSave}
              isLoading={loading}
            />
            <Button
              text="Forgot Password?"
              btnClass={style.forgotBtn}
              isLoading={loading}
            />
          </div>
        </form>
      </div>
    </>
  );
};

export default PasswordSecurity;
