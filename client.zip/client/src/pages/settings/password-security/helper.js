import * as yup from "yup";

export const passwordUpdateSchema = yup.object().shape({
  current_password: yup.string().required("Current Password is required"),
  new_password: yup.string().required("New password is required"),
  retype_password: yup.string().required("Re-type Password is required"),
});
