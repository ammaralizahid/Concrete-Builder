import React from "react";
import { Link, useLocation } from "react-router-dom";
import AccountSettings from "./account-setting";
import ConcreteMixes from "./concrete-mixes";
import Notification from "./notification";
import PasswordSecurity from "./password-security";

import style from "./setting.module.scss";

const Settings = () => {
  const navLinkArr = [
    {
      title: "Account Setting",
      path: "/settings/account-setting",
    },
    {
      title: "Password & Security",
      path: "/settings/password-security",
    },
    {
      title: "Concrete Mixes",
      path: "/settings/concrete-mixes",
    },
    {
      title: "Notifications",
      path: "/settings/notifications",
    },
    {
      title: "Drawings",
      path: "/settings/drawings",
    },
  ];
  const { pathname } = useLocation();
  console.log(pathname);
  return (
    <div className={style.main_wrapper}>
      <h2 style={{ marginBottom: "25px" }}>Settings</h2>
      <nav className={style.navbar}>
        <ul>
          {navLinkArr.map((ele) => {
            return (
              <li key={ele.title}>
                <Link
                  className={`${pathname.includes(ele.path) && style.active}`}
                  to={ele.path}
                >
                  {ele.title}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className={style.bodyWrapper}>
        {pathname.includes("/settings/account-setting") && <AccountSettings />}
        {pathname.includes("/settings/password-security") && (
          <PasswordSecurity />
        )}
        {pathname.includes("/settings/concrete-mixes") && <ConcreteMixes />}
        {pathname.includes("/settings/notifications") && <Notification />}
        {pathname.includes("/settings/drawings") && <h2>asdfadsf</h2>}
      </div>
    </div>
  );
};

export default Settings;
