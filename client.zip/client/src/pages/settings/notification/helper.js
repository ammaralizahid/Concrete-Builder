export const columns = [
  {
    key: "recipient",
    name: "Recipient",
    width: "50px",
  },
  {
    key: "alert_type",
    name: "Alert Type",
    width: "50px",
  },
  {
    key: "status",
    name: "Status",
    width: "50px",
  },
  {
    key: "action",
    name: "",
    width: "50px",
  },
];
