import * as yup from "yup";

export const notificationAddSchema = yup.object().shape({
  name: yup.string().required("Name is required"),
  email: yup.string().required("Email is required").email(),
  phone_number: yup.string().required("Phone number is required"),
});
