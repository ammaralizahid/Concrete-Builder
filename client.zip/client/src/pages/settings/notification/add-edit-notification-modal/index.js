/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Modal from "components/modal";
import Button from "components/button";
import TextArea from "components/textarea";

import { notificationAddSchema } from "./helper";
import { apiRequest } from "utils/helper";

import style from "./add-edit.module.scss";
import Input from "components/input";

const AddEditNotification = ({
  openCastModal,
  setOpenCastModal,
  fetchCastingList,
  singleCastData,
  setSingleCastData,
}) => {
  const [loading, setLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(notificationAddSchema),
  });

  const onSubmit = async (data) => {
    console.log(data);
  };

  const handleClose = () => {
    setOpenCastModal(false);
    Object?.keys(singleCastData)?.length && setSingleCastData({});
    reset({});
  };

  return (
    <>
      <Modal
        open={openCastModal}
        className={style.wrapperClass}
        handleClose={handleClose}
      >
        <div className={style.headingClass}>
          <h2>Notification</h2>
        </div>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div style={{ marginTop: "20px" }}>
            <Input
              label={"Name"}
              name={"name"}
              register={register}
              errorMessage={errors?.name?.message}
            />
          </div>
          <div style={{ marginTop: "20px" }}>
            <Input
              label={"Email"}
              name={"email"}
              register={register}
              errorMessage={errors?.email?.message}
            />
          </div>
          <div style={{ marginTop: "20px" }}>
            <Input
              label={"Phone Number"}
              name={"phone_number"}
              register={register}
              errorMessage={errors?.phone_number?.message}
            />
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              width: "100%",
              justifyContent: "flex-end",
              marginTop: "20px",
            }}
          >
            <p className={style.p} onClick={handleClose}>
              Cancel
            </p>
            <Button text="Create" isLoading={loading} />
          </div>
        </form>
      </Modal>
    </>
  );
};

export default AddEditNotification;
