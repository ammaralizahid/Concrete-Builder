/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";

import Table from "components/table";
import Button from "components/button";
// import AddEditCastModal from "./add-edit-cast-modal";

import { columns } from "./helper";

import plus from "assets/icons/plus.svg";
import edit from "assets/icons/pencil-icon.svg";
import style from "./notification.module.scss";
import AddEditNotification from "./add-edit-notification-modal";

const Notification = () => {
  const [projectName, setProjectName] = useState("");
  const [castingData, setCastingData] = useState({});
  const [singleCastData, setSingleCastData] = useState({});
  const [openCastModal, setOpenCastModal] = useState(false);

  //   const handleSaveClick = async () => {
  //     const res = await apiRequest({
  //       method: "put",
  //       url: "projects",
  //       body: { id: castingData?._id, projectName: projectName },
  //     });
  //     console.log(res);
  //     setEditProjectName(false);
  //   };

  //   const handleEdit = (row) => {
  //     setOpenCastModal(true);
  //     setSingleCastData({ ...row });
  //   };

  //   const fetchCastingList = async () => {
  //     const res = await fetchCastList();
  //     if (res !== "Unauthorized") {
  //       setCastingData({ ...res?.data?.project });
  //       setProjectName(res.data.project.projectName);
  //       store.dispatch(setCastList(res.data.project.castings));
  //     } else {
  //       store.dispatch(setLogout(""));
  //       navigate("/login");
  //     }
  //   };

  //   useEffect(() => {
  //     fetchCastingList();
  //   }, []);

  return (
    <>
      <div className={style.mainClass}>
        <div className={style.flexClass}>
          <div className={style.right}>
            <Button
              text="Add Recipient"
              icon={plus}
              handleClick={() => setOpenCastModal(true)}
            />
          </div>
        </div>
        <Table
          rows={castingData?.castings}
          columns={columns}
          minWidth="1400px"
          //   handleEdit={handleEdit}
          tableHeight={style.tableHeight}
          deleteApiUrl="projects/castings"
          //   fetchTableList={fetchCastingList}
        />
      </div>
      <AddEditNotification
        openCastModal={openCastModal}
        setOpenCastModal={setOpenCastModal}
        // fetchCastingList={fetchCastingList}
        singleCastData={singleCastData}
        setSingleCastData={setSingleCastData}
      />
    </>
  );
};

export default Notification;
