/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import Button from "components/button";
import Input from "components/input";

import { accountSchema } from "./helper";

import style from "./setting.module.scss";

const AccountSettings = () => {
  const [loading, setLoading] = useState(false);

  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(accountSchema),
  });

  const onSubmit = async (data) => {
    console.log(data);
  };

  return (
    <>
      <div className={style.wrapperClass}>
        <div className={style.headingClass}>
          <h2>Account</h2>
        </div>
        <div className={style.profileImgWrapper}>
          {/* <img src={""} className={style.profileImg} alt={"profile-img"} /> */}
          <div className={style.profileImg}></div>
          <Button text={"Upload"} btnClass={style.uploadBtn} />
          <Button text={"Remove"} btnClass={style.removeBtn} />
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className={style.formWrapper}>
          <div className={style.formInnerWrapper}>
            <Input
              label={"First Name"}
              name={"first_name"}
              register={register}
              errorMessage={errors?.first_name?.message}
            />
            <Input
              label={"Last Name"}
              name={"last_name"}
              register={register}
              errorMessage={errors?.last_name?.message}
            />
            <Input
              label={"email"}
              name={"email"}
              register={register}
              errorMessage={errors?.email?.message}
            />
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              width: "100%",
              justifyContent: "flex-end",
              marginTop: "30px",
            }}
          >
            <Button
              text="Save"
              type={"submit"}
              btnClass={style.btnSave}
              isLoading={loading}
            />
          </div>
        </form>
      </div>
    </>
  );
};

export default AccountSettings;
