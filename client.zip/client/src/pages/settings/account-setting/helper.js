import * as yup from "yup";

export const accountSchema = yup.object().shape({
  first_name: yup.string().required("Last Name is required"),
  last_name: yup.string().required("Last Name is required"),
  email: yup.string().required("Email is required").email(),
});
