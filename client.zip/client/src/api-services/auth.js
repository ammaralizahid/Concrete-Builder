import axios from "utils/axios";
import { store, setUser } from "store";
import { FORGET_PASS_ROUTE, LOGIN_ROUTE, SIGNUP_ROUTE } from "utils/endpoints";

export const login = async ({ data, navigate, setIsLoading }) => {
  setIsLoading(true);
  const res = await axios.post(LOGIN_ROUTE, data);
  if (res.status === 201) {
    console.log(res);
    store.dispatch(
      setUser({ user: res.data.user, token: res.headers.authorization })
    );
    setIsLoading(false);
    navigate("/");
  }
  setIsLoading(false);
};

export const signUp = async ({ data, navigate }) => {
  const res = await axios.post(SIGNUP_ROUTE, data);
  if (res.status === 201) {
    store.dispatch(
      setUser({ user: res.data.user, token: res.headers.authorization })
    );
    navigate("/");
  }
};

export const forgetPass = async ({ data, setSuccess }) => {
  const res = await axios.post(FORGET_PASS_ROUTE, data);
  if (res.status === 200) {
    setSuccess(true);
  }
};
