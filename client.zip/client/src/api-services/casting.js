import axios from "utils/axios";
import { FETCH_CASTING_LIST } from "utils/endpoints";

export const fetchCastList = async () => {
  const res = await axios.get(FETCH_CASTING_LIST);
  console.log(res);
  if (res.status === 200) {
    return res;
  } else if (res === "Unauthorized") {
    return res;
  }
};
