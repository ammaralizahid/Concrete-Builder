import { memo } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";

import { useAppSelector } from "store/hooks";
import { privateRoutes, publicRoutes } from "./helper";

import Layout from "components/layout";
import { Navbar } from "components/navbar";

const Routing = () => {
  const { token } = useAppSelector((state) => state?.app);
  const { pathname } = useLocation();
  return (
    <>
      {!token && (
        <Routes>
          {publicRoutes?.map(({ path, element }, index) => (
            <Route
              key={index}
              path={path}
              element={
                <>
                  <Navbar />
                  {element}
                </>
              }
            />
          ))}
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      )}

      {token && (
        <Routes>
          {privateRoutes?.map(({ path, element }, index) =>
            pathname.includes("/settings") ? (
              <Route
                key={index}
                path={path}
                element={
                  <>
                    <Navbar />
                    {element}
                  </>
                }
              />
            ) : (
              <Route
                key={index}
                path={path}
                element={<Layout>{element}</Layout>}
              />
            )
          )}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      )}
    </>
  );
};

export default memo(Routing);
