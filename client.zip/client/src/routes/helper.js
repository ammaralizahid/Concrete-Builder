import Home from "pages/casting";
import Login from "pages/auth/login";
import SignUp from "pages/auth/sign-up";
import ForgotPassword from "pages/auth/reset-password";
import CastingDetails from "./../pages/casting-detailes/index";
import Settings from "pages/settings";

export const publicRoutes = [
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/forgot-password",
    element: <ForgotPassword />,
  },
  {
    path: "/sign-up",
    element: <SignUp />,
  },
];
export const privateRoutes = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/casting-details",
    element: <CastingDetails />,
  },
  {
    path: "/settings",
    element: <Settings />,
  },
  {
    path: "/settings/account-setting",
    element: <Settings />,
  },
  {
    path: "/settings/password-security",
    element: <Settings />,
  },
  {
    path: "/settings/concrete-mixes",
    element: <Settings />,
  },
  {
    path: "/settings/notifications",
    element: <Settings />,
  },
  {
    path: "/settings/drawings",
    element: <Settings />,
  },
];
