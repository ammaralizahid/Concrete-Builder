import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  token: localStorage.getItem("token") || "",
  user: {},
  castList: [],
};

export const appSlice = createSlice({
  name: "app",
  initialState,
  reducers: {
    setUser(state, { payload: { user, token } }) {
      state.user = user;
      localStorage.setItem("token", token);
      state.token = token;
    },
    setLogout(state, action) {
      localStorage.setItem("token", action.payload);
      state.token = action.payload;
    },
    setCastList(state, action) {
      state.castList = action.payload;
    },
  },
});
