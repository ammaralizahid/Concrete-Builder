import axios from "./axios";

export const apiRequest = async ({ method, url, body, params, config }) => {
  try {
    const res = await axios[method](
      url,
      {
        ...(body && body),
        ...(params && { params }),
      },
      { ...config }
    );

    return res;
  } catch (err) {
    return err.response;
  }
};
