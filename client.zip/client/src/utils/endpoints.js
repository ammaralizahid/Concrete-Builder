export const LOGIN_ROUTE = "auth/login/";
export const SIGNUP_ROUTE = "auth/sign-up";
export const FORGET_PASS_ROUTE = "auth/forgot-password/";

export const FETCH_CASTING_LIST = "projects/";
