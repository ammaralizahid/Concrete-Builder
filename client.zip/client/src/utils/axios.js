import axios from "axios";

import { createNotification } from "common/create-notification";
import { store } from "store";

if (process.env.NODE_ENV === "development") {
  axios.defaults.baseURL = "https://concrete-ai.herokuapp.com/api/";
} else {
  axios.defaults.baseURL = "https://concrete-ai.herokuapp.com/api/";
}

axios.interceptors.request.use(
  (req) => {
    const state = store.getState();
    if (state?.app?.token) {
      req.headers.Authorization = state?.app?.token;
    }
    return req;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  (res) => {
    console.log(res);
    if (
      ["post", "put", "delete"].includes(res.config.method) &&
      !res.config.url.includes("login")
    ) {
      createNotification("success", "Success", res?.data.msg);
    }
    return res;
  },
  (error) => {
    console.error(error.response);
    createNotification(
      "error",
      error?.response?.data.msg || "Something went wrong "
    );
    if (
      error?.response?.statusText === "Unauthorized" &&
      error?.response?.status === 401
    ) {
      return "Unauthorized";
    }
    return Promise.reject(error);
  }
);

export default axios;
