import React from "react";
import Modal from "components/modal";

import style from "./success.module.scss";
import Button from "components/button";

const CreatedSuccessModal = ({ successModalOpen, setSuccessModalOpen }) => {
  return (
    <Modal
      open={successModalOpen}
      handleClose={() => setSuccessModalOpen(false)}
      className={style.modal}
    >
      <div className={style.main}>
        <h1>Created successfully!</h1>

        <div className={style.actionDiv}>
          <Button text={"Ok"} handleClick={() => setSuccessModalOpen(false)} />
        </div>
      </div>
    </Modal>
  );
};

export default CreatedSuccessModal;
