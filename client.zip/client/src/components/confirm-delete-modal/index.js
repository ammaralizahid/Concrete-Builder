import React from "react";
import Modal from "components/modal";

import style from "./delete.module.scss";
import Button from "components/button";
//  deleteLoading = { deleteLoading };
//  handleDeleteRow = { handleDeleteRow };
//  setDeleteId = { setDeleteId };
const DeleteConfirmModal = ({
  setDeleteId,
  deleteLoading,
  deleteModalOpen,
  handleDeleteRow,
  setDeleteModalOpen,
}) => {
  const handleClose = () => {
    setDeleteModalOpen && setDeleteModalOpen(false);
    setDeleteId && setDeleteId(null);
  };

  return (
    <Modal
      open={deleteModalOpen}
      handleClose={() => setDeleteModalOpen(false)}
      className={style.modal}
    >
      <div className={style.main}>
        <div className={style.imgDiv}>
          <img src="" alt="" />
        </div>
        <div className={style.contentDiv}>
          <h1>Are you sure?</h1>
          <p>
            Deleting will permanently remove this item from the system.{" "}
            <strong> This cannot be undone!</strong>
          </p>
        </div>
        <div className={style.actionDiv}>
          <Button
            text={"Cancel"}
            btnClass={style.cancelBtn}
            handleClick={handleClose}
          />
          <Button
            text={"Delete"}
            btnClass={style.deleteBtn}
            isLoading={deleteLoading}
            handleClick={handleDeleteRow}
          />
        </div>
      </div>
    </Modal>
  );
};

export default DeleteConfirmModal;
