import React from "react";

import Loading from "components/loading";

import style from "./button.module.scss";

const Button = ({
  text,
  icon,
  type,
  user_id,
  btnClass,
  disabled,
  textClass,
  isLoading,
  handleClick,
  btnLoaderClass,
}) => {
  return (
    <>
      <button
        className={`${style.btn} ${btnClass}`}
        type={type}
        onClick={handleClick}
        disabled={isLoading || disabled ? true : false}
        style={{
          pointerEvents: isLoading ? "none" : "auto",
        }}
        data-id={user_id}
      >
        {isLoading ? (
          <Loading className={btnLoaderClass} />
        ) : (
          <>
            {icon && <img src={icon} alt="" className={style.img} />}
            {text && (
              <span
                className={`${style.btnTitle} ${textClass}`}
                style={{ marginLeft: icon ? "20px " : "" }}
              >
                {text}
              </span>
            )}
          </>
        )}
      </button>
    </>
  );
};

export default Button;
