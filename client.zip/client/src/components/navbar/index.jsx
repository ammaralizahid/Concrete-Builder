import React from "react";
import { Link } from "react-router-dom";

import { useAppSelector } from "store/hooks";

import style from "./navbar.module.scss";

export const Navbar = () => {
  const { token } = useAppSelector((state) => state?.app);

  return (
    <nav className={style.navbar}>
      <div className={style.titleDiv}>
        <h4>ConcreteAl</h4>
      </div>
      {token && (
        <div className={style.flex}>
          <li>
            <Link to={"/"}>Castings</Link>
          </li>
          <li>Analysis</li>
          <li>Devices</li>

          <li>
            <div className={style.profileDiv}>
              <div className={style.roundDiv}></div>
            </div>
          </li>
        </div>
      )}
    </nav>
  );
};
