import React from "react";

import icon from "assets/Vector.svg";
import style from "./accordion.module.scss";

const TableDiv = ({ body }) => {
  return (
    <div className={style.ansOpen}>
      <table>
        <tr>
          <th>
            Device ID <img src={icon} alt="" />
          </th>
          <th>
            Datapoint - Remarks <img src={icon} alt="" />
          </th>
        </tr>
        {body.map((ele, index) => (
          <tr key={index}>
            <td>{ele.deviceId}</td>
            <td style={{ display: "flex", alignItems: "center" }}>
              {ele.dataPoints.map((d, ind) => (
                <div key={ind} className={style.chip}>
                  <p>
                    {d.text} - <span>{d.variant}</span>{" "}
                  </p>
                </div>
              ))}
            </td>{" "}
          </tr>
        ))}
      </table>
    </div>
  );
};

export default TableDiv;
