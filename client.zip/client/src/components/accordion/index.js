import { useState } from "react";

import TableDiv from "./ans-table";
import style from "./accordion.module.scss";
import ArrowUp from "assets/chevron_up.svg";
import edit from "assets/Edit Square.svg";
import play from "assets/icons/play-icon.svg";

import Button from "components/button";

const Accordion = ({ setOpenCastModal, setOpenStartModel }) => {
  const [open, setOpen] = useState(false);

  const handleOpen = (index) => {
    if (open === index) {
      return setOpen(null);
    } else {
      setOpen(index);
    }
  };

  return (
    <>
      {accordionData.map((ele, index) => (
        <div key={index} className={style.Accordion_Wrapper}>
          <div className={style.quesDiv}>
            {ele.questionPara.map((p, index) => (
              <p className={style.qes} key={index}>
                {p.text}
              </p>
            ))}
            <p className={style.qes}>
              <Button
                text={"Edit"}
                icon={edit}
                textClass={style.text}
                handleClick={() => setOpenCastModal(true)}
              />
              <Button
                text={"Start"}
                btnClass={style.btn}
                icon={play}
                handleClick={() => setOpenStartModel(true)}
                textClass={style.text}
              />
              <div
                className={style.imgDiv}
                onClick={() => handleOpen(index)}
                style={{
                  transform:
                    open === index ? "rotate(-180deg)" : "rotate(0deg)",
                }}
              >
                <img src={ele.icon} alt="" />
              </div>
            </p>
          </div>
          {open === index && <TableDiv body={ele.body} />}
        </div>
      ))}
    </>
  );
};

export default Accordion;

const accordionData = [
  {
    questionPara: [
      { text: "11HPB2" },
      { text: "50MPa" },
      { text: "Lorem Ipsum ..." },
      { text: "05 May, 7PM" },
    ],
    icon: ArrowUp,
    body: [
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
    ],
  },
  {
    questionPara: [
      { text: "11HPB2" },
      { text: "50MPa" },
      { text: "Lorem Ipsum ..." },
      { text: "05 May, 7PM" },
    ],
    icon: ArrowUp,
    body: [
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
    ],
  },
  {
    questionPara: [
      { text: "11HPB2" },
      { text: "50MPa" },
      { text: "Lorem Ipsum ..." },
      { text: "05 May, 7PM" },
    ],
    icon: ArrowUp,
    body: [
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
    ],
  },
  {
    questionPara: [
      { text: "11HPB2" },
      { text: "50MPa" },
      { text: "Lorem Ipsum ..." },
      { text: "05 May, 7PM" },
    ],
    icon: ArrowUp,
    body: [
      {
        deviceId: "A007",
        dataPoints: [
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
          {
            text: "Data 1",
            variant: "Top",
          },
        ],
      },
    ],
  },
];
