import React from "react";
import style from "./underline-input.module.scss";

const UnderlineInput = ({
  label,
  type,
  name,
  value,
  readOnly,
  register,
  onChange,
  isDisable,
  unit,
  inputClass,
  placeholder,
  errorMessage,
  className,
}) => {
  return (
    <>
      <div className={`${style.inputContainer} ${className}`}>
        {label && <label>{label}</label>}
        <div
          className={style.borderDiv}
          style={{
            borderBottom: errorMessage
              ? "1px solid #ff5050"
              : " 1px solid #DEDEDE",
          }}
        >
          <input
            className={inputClass}
            type={type || "text"}
            placeholder={placeholder || ""}
            name={name || ""}
            value={value && value}
            onChange={onChange && onChange}
            readOnly={readOnly || false}
            disabled={isDisable || false}
            {...(register && register(name))}
            style={{
              color: errorMessage ? "#ff5050" : "#6e6d6d",
            }}
          />
          {unit && <p>{unit}</p>}
        </div>
        {errorMessage && (
          <span className={style.errorMessage}>{errorMessage}</span>
        )}
      </div>
    </>
  );
};

export default UnderlineInput;
