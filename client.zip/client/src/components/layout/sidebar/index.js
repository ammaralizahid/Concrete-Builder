/* eslint-disable react-hooks/exhaustive-deps */
import React, { Fragment, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

import Card from "components/card";
import Input from "components/input";

import { sidebarList } from "./helper";

import arrowDown from "assets/icons/sidebar-icons/down-arrow.png";
import searchIcon from "assets/search.png";
import style from "./sidebar.module.scss";

const Sidebar = ({ openSidebar, setOpenSidebar }) => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { castList } = useSelector((state) => state?.app);

  const [open, setOpen] = useState(false);
  const [list, setList] = useState([]);
  const [selectValue, setSelectValue] = useState("");

  useEffect(() => {
    setList(castList);
  }, [castList]);

  const handleNavigate = (path) => {
    navigate(path);
    openSidebar && setOpenSidebar(false);
  };

  const handleOpen = (index) => {
    if (open === index) {
      setOpen(null);
    } else {
      setOpen(index);
    }
  };

  const handleSearch = (e) => {
    setSelectValue(e.target.value);
    if (e.target.value === "") {
      setList(castList);
    } else {
      setList(
        list?.filter((ele) =>
          ele?.castName?.toLowerCase().includes(e.target.value)
        )
      );
    }
  };

  return (
    <>
      <Card className={style.sidebarCard}>
        <div className={style.sideHeader}>
          <h1>ConcreteAl</h1>
        </div>
        <div className={style.listDiv}>
          <ul className={style.ul}>
            <ul className={style.ul}>
              {sidebarList?.map((ele, index) => (
                <Fragment key={index}>
                  <li
                    onClick={() => {
                      !ele.child && handleNavigate(ele.path);
                      handleOpen(index);
                    }}
                    className={
                      !ele?.child && pathname.includes(ele.active)
                        ? style.activeClass
                        : ""
                    }
                  >
                    <div>
                      <img src={ele.icon} alt="" />
                      <p className={style.main_title}>{ele.title}</p>
                    </div>

                    {ele.child && (
                      <img
                        src={arrowDown}
                        alt=""
                        className={style.arrowDown}
                        style={{
                          transform: `rotate(${
                            open === index ? "180deg" : "0deg"
                          })`,
                        }}
                      />
                    )}
                  </li>
                  {ele.child && open === index && (
                    <div className={style.childDiv}>
                      <Input
                        placeholder={"search"}
                        icon={searchIcon}
                        value={selectValue}
                        onChange={(e) => handleSearch(e)}
                      />
                      {list?.length > 0 && open === index ? (
                        <div style={{ height: "150px", overflow: "auto" }}>
                          {list.map((ele, index) => (
                            <li
                              key={index}
                              onClick={() => handleNavigate("/casting-details")}
                              className={`
                           
                              ${style.menu_wrapper} `}
                            >
                              <div className={style.side_menu}>
                                {/* <img src={ele?.icon} alt="" /> */}
                                <p>{ele?.castName} </p>
                              </div>
                            </li>
                          ))}
                        </div>
                      ) : (
                        <h4
                          style={{
                            textAlign: "center",
                            padding: "10px 0px",
                            color: "#5e5e5e",
                          }}
                        >
                          No Casting Found!
                        </h4>
                      )}
                    </div>
                  )}
                </Fragment>
              ))}
            </ul>
          </ul>
        </div>
      </Card>
    </>
  );
};

export default Sidebar;
