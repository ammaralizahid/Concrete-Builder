import castingIcon from "assets/icons/sidebar-icons/sidebar_casting.svg";
import analysisIcon from "assets/icons/sidebar-icons/sidebar_analysis.svg";
import deviceIcon from "assets/icons/sidebar-icons/sidebar_devices.svg";

export const sidebarList = [
  {
    title: "Casting",
    active: "casting",
    icon: castingIcon,
    child: [
      {
        title: "Lvl 11 - Phase 2",
        path: "/casting-details",
        active: "analysis",
      },
      {
        title: "Lvl 11 - Phase 3",
        path: "/casting-details",
        active: "device",
      },
      {
        title: "Lvl 11 - Phase 3",
        path: "/casting-details",
        active: "device",
      },
      {
        title: "Lvl 11 - Phase 3",
        path: "/casting-details",
        active: "device",
      },
      {
        title: "Lvl 11 - Phase 3",
        path: "/casting-details",
        active: "device",
      },
    ],
  },
  {
    title: "Analysis",
    active: "analysis",
    icon: analysisIcon,
  },
  {
    title: "Device",
    active: "device",
    icon: deviceIcon,
  },
];
