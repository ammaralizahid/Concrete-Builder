import React from "react";
import { Link, useNavigate } from "react-router-dom";

import { setLogout } from "store";
import { useAppDispatch } from "store/hooks";

import menu from "assets/icons/navbar-icons/menu.svg";
import home from "assets/icons/navbar-icons/nav_home.svg";
import nav_arrow from "assets/icons/navbar-icons/down-arrow.png";
import nav_reload from "assets/icons/navbar-icons/nav_reload.svg";
import nav_logout from "assets/icons/navbar-icons/nav_logout.svg";
import nav_setting from "assets/icons/navbar-icons/nav_setting.svg";
import style from "./navbar.module.scss";

export const Navbar = ({ setOpenSidebar }) => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(setLogout(""));
    navigate("/login");
  };

  return (
    <nav className={style.navbar}>
      <div className={style.titleDiv}>
        <img
          src={menu}
          alt=""
          className={style.menuIcon}
          onClick={() => setOpenSidebar(true)}
        />
      </div>

      <div className={style.flex}>
        <li>
          <img src={home} alt="" />
        </li>
        <li>
          <Link to={"/settings/account-setting"}>
            <img src={nav_setting} alt="setting icon" />
          </Link>
        </li>
        <li>
          <img src={nav_reload} alt="" />
        </li>
        <li>
          <img src={nav_logout} alt="" onClick={handleLogout} />
        </li>
        <li>
          <div className={style.profileDiv}>
            <div className={style.roundDiv}></div>
            <img src={nav_arrow} alt="" className={style.arrowImg} />
          </div>
        </li>
      </div>
    </nav>
  );
};
