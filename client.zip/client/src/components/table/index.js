import React, { useState } from "react";

import DeleteConfirmModal from "components/confirm-delete-modal";
import { apiRequest } from "utils/helper";

import style from "./table.module.scss";
import edit from "assets/Edit Square.svg";
import delIcon from "assets/icons/delete-icon.svg";

const Table = ({
  columns,
  rows,
  minWidth,
  className,
  tableHeight,
  handleEdit,
  deleteApiUrl,
  fetchTableList,
}) => {
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  const handleDeleteRow = async () => {
    setDeleteLoading(true);
    if (deleteApiUrl) {
      const res = await apiRequest({
        method: "delete",
        url: `${deleteApiUrl}/?id=${deleteId}`,
      });
      if (res.status === 200) {
        setDeleteId(null);
        fetchTableList?.();
      }
    }
    setDeleteModalOpen(false);
    setDeleteLoading(false);
  };

  return (
    <>
      <div className={`${style.tableWrapper} ${tableHeight}`}>
        <div className={style.table} style={{ minWidth: minWidth || "1200px" }}>
          <div className={style.thead}>
            {columns?.map((column, index) => (
              <div
                key={index}
                className={style.heading}
                style={{
                  minWidth: column?.width ? column?.width : "50px",
                  textAlign: column?.alignText ? column?.alignText : "center",
                }}
              >
                <p>
                  <span className={style.headingTitle}>{column.name}</span>
                </p>
              </div>
            ))}
          </div>

          {rows?.length > 0 ? (
            rows?.map((row, index) => (
              <div
                className={style.tr}
                style={{ display: "flex", alignItems: "center" }}
                key={index}
              >
                {columns.map((column, colIndex) => (
                  <div
                    key={colIndex}
                    style={{
                      minWidth: column?.width ? column?.width : "50px",
                      padding: "8px",
                      width: "100%",
                    }}
                    className={`${style.td} ${className}  `}
                  >
                    {column.key !== "actions" ? (
                      <div>
                        <p
                          style={{
                            textAlign: column?.alignText
                              ? column?.alignText
                              : "center",
                          }}
                        >
                          {textShow(row, column)}
                        </p>
                      </div>
                    ) : (
                      <div className={style.iconsDiv}>
                        <div
                          style={{
                            background: "#3F51B5",
                            padding: "8px 18px",
                            display: "flex",
                            justifyContent: "space-between",
                            borderRadius: "5px",
                            alignItems: "center",
                            width: "89px",
                            color: "white",
                            cursor: "pointer",
                          }}
                          onClick={() => handleEdit && handleEdit(row)}
                        >
                          <img
                            src={edit}
                            alt=""
                            style={{ width: "18px ", marginRight: "5px" }}
                          />
                          Edit
                        </div>
                        <div
                          style={{
                            background: "#F26D6D",
                            marginLeft: "10px",
                            padding: "8px 18px",
                            display: "flex",
                            justifyContent: "space-between",
                            borderRadius: "5px",
                            alignItems: "center",
                            width: "110px",
                            color: "white",
                            cursor: "pointer",
                          }}
                          onClick={() => {
                            row?._id && setDeleteId(row?._id);
                            setDeleteModalOpen(true);
                          }}
                        >
                          <img
                            src={delIcon}
                            style={{ width: "15px ", marginRight: "5px" }}
                            alt=""
                          />
                          Delete
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ))
          ) : (
            <div className={style.nodataDiv}>
              <h1 className={style.nodata}>No Data Found</h1>
            </div>
          )}
        </div>
      </div>

      <DeleteConfirmModal
        deleteModalOpen={deleteModalOpen}
        setDeleteModalOpen={setDeleteModalOpen}
        deleteLoading={deleteLoading}
        handleDeleteRow={handleDeleteRow}
        setDeleteId={setDeleteId}
      />
    </>
  );
};

export default Table;

const textShow = (row, col) => {
  if (row[col.key]) {
    if (col?.formatter) {
      return col.formatter(row[col.key]);
    }
    return row[col.key];
  } else {
    return "--";
  }
};
