require("dotenv").config();
const jwt = require("jsonwebtoken");

const ensureAuth = async (req, res, next) => {
  const token = req?.header("Authorization");

  if (token) {
    try {
      const decoded = await jwt.verify(token, process.env.JWT_KEY);
      req.body.user_id = decoded.user_id;
      req.body.user_email = decoded.user_email;

      next();
    } catch (err) {
      return res.status(401).json({ msg: "Session Expired!" });
    }
  } else {
    return res.status(401).json({ msg: "Login Required!" });
  }
};

const Validator = (schema, params) => {
  return (req, res, next) => {
    const { error } = schema.validate(
      params === "body"
        ? req.body
        : params === "params"
        ? req.params
        : req.query
    );
    if (error) return res.status(400).send({ msg: error.details[0].message });

    next();
  };
};

module.exports = { ensureAuth, Validator };
