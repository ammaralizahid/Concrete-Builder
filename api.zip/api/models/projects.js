"use-strict";
require("dotenv").config();
const mongoose = require("mongoose");

const Project = new mongoose.Schema({
  userId: {
    type: String,
  },
  projectName: {
    type: String,
    required: true,
  },
  castings: [
    {
      structures: [
        {
          structure: {
            type: String,
            // required: true,
          },
          remarks: {
            type: String,
          },
          startMonitoringDate: {
            type: Date,
          },
          startMonitoringTime: {
            type: String,
          },
          endMonitoringDate: {
            type: Date,
          },
          endMonitoringTime: {
            type: String,
          },
          done: {
            type: Boolean,
            default: false,
          },
          devices: [
            {
              deviceId: {
                type: String,
                // required: true,
              },
              dataPoints: [
                {
                  dataPoint: {
                    type: String,
                    // required: true,
                  },
                  remarks: {
                    type: String,
                  },
                },
              ],
            },
          ],
          targets: [
            {
              name: {
                type: String,
                // required: true,
              },
              value: {
                type: String,
              },
              unit: {
                type: String,
              },
            },
          ],
        },
      ],
      castName: {
        type: String,
      },
      concreteInformation: {
        type: String,
      },
      concreteSupplier: {
        type: String,
      },
      concreteType: {
        type: String,
      },
      portland: {
        type: String,
      },
      coarseAggregate: {
        type: String,
      },
      flyAsh: {
        type: String,
      },
      retardingMixture: {
        type: String,
      },
      water: {
        type: String,
      },
      fineAggregate: {
        type: String,
      },
      acceleratingAdmixture: {
        type: String,
      },
      concreteGrade: {
        type: String,
      },
      q: {
        type: String,
      },
      rt: {
        type: String,
      },
      su: {
        type: String,
      },
      k: {
        type: String,
      },
      m0: {
        type: String,
      },
      offset: {
        type: String,
      },
      remarks: {
        type: String,
      },
    },
  ],
});

module.exports = mongoose.model("projects", Project);
