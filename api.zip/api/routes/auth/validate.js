const Joi = require("joi");

module.exports.signUpValidator = Joi.object({
  img: Joi.string().allow("").allow(null).optional(),
  firstName: Joi.string().min(3).required(),
  lastName: Joi.string().min(3).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(5).max(55).required(),
});

module.exports.loginValidator = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(5).max(55).required(),
});

module.exports.forgotPasswordValidator = Joi.object({
  email: Joi.string().email().required(),
});
