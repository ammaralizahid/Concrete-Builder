const express = require("express");
const bcrypt = require("bcrypt");

const { ensureAuth, Validator } = require("../../middleware/ensure-auth");
const User = require("../../models/users");
const Project = require("../../models/projects");
const {
  signUpValidator,
  loginValidator,
  forgotPasswordValidator,
} = require("./validate");

const app = express.Router();

app.post("/sign-up", Validator(signUpValidator, "body"), async (req, res) => {
  const { img, firstName, lastName, email, password } = req.body;

  const userByEmail = await User.findOne({
    email,
  });
  if (userByEmail) {
    return res.status(409).json({ msg: "Email already exists!" });
  }

  const newUser = new User({
    ...(img && { img: img }),
    firstName,
    lastName,
    email,
    password,
  });
  const user = await newUser.save();

  const token = await user.generateAuthToken();

  // if (img) {

  //   const base64Image = img.split(";base64,").pop();
  //   fs.writeFileSync(
  //     `./public/images/${newUser?.upsertedId}.png`,
  //     base64Image,
  //     {
  //       encoding: "base64",
  //     }
  //   );
  // }

  const newProject = new Project({
    userId: user._id,
    projectName: "Project Name",
  });
  await newProject.save();

  const data = {
    _id: user._id,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
  };

  return res.header("authorization", token).status(201).json({ user: data });
});

app.post("/login", Validator(loginValidator, "body"), async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({
    email,
  });
  // .select({ email: 1})
  if (!user) {
    return res.status(404).json({ msg: "User not found!" });
  }

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    return res.status(403).send({ msg: "Invalid Password!" });
  }

  const token = await user.generateAuthToken();

  const data = {
    _id: user._id,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
  };

  return res.header("authorization", token).status(201).json({ user: data });
});

app.post(
  "/forgot-password",
  Validator(forgotPasswordValidator, "body"),
  async (req, res) => {
    const { email } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).send({ msg: "Invalid email!" });
    }

    const token = await user.generateAuthToken();

    if (token) {
      try {
        // Send Reset Password email
      } catch (err) {
        console.log(err);
        return res.status(400).send({ msg: "Message sending failed!" });
      }
    }

    res.status(200).send({ msg: "Password reset link sent to your email" });
  }
);

app.get("/:id", ensureAuth, async (req, res) => {
  const id = req.params.id;

  if (!id || id <= 0) {
    return res.status(401).send({ msg: "Id is missing!" });
  }

  const user = await User.findById(id);
  if (!user) {
    return res.status(404).send({ msg: "User not found!" });
  }

  const data = {
    _id: user._id,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
  };

  res.status(200).json({ user: data });
});

module.exports = app;
