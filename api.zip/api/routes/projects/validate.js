const Joi = require("joi");

module.exports.projectNameUpdateValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  id: Joi.string().required(),
  projectName: Joi.string().min(3).max(55).required(),
});

module.exports.addCastingValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  advanceSetting: Joi.boolean().required(),
  castName: Joi.string().required(),
  concreteInformation: Joi.string().required(),
  concreteSupplier: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  concreteType: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  portland: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  coarseAggregate: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  flyAsh: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  retardingMixture: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  water: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  fineAggregate: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  acceleratingAdmixture: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  concreteGrade: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  q: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  rt: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  su: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  k: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  m0: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  offset: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  remarks: Joi.string(),
});

module.exports.updateCastingValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  id: Joi.string().required(),
  advanceSetting: Joi.boolean().required(),
  castName: Joi.string().required(),
  concreteInformation: Joi.string().required(),
  concreteSupplier: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  concreteType: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  portland: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  coarseAggregate: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  flyAsh: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  retardingMixture: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  water: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  fineAggregate: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  acceleratingAdmixture: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string(),
  }),
  concreteGrade: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  q: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  rt: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  su: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  k: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  m0: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  offset: Joi.when("advanceSetting", {
    is: true,
    then: Joi.string().required(),
  }),
  remarks: Joi.string(),
});

module.exports.deleteCastingValidator = Joi.object({
  id: Joi.string().required(),
});
