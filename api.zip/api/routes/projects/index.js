const express = require("express");

const { ensureAuth, Validator } = require("../../middleware/ensure-auth");
const Project = require("../../models/projects");
const {
  projectNameUpdateValidator,
  addCastingValidator,
  updateCastingValidator,
  deleteCastingValidator,
} = require("./validate");

const app = express.Router();

app.put(
  "/",
  ensureAuth,
  Validator(projectNameUpdateValidator, "body"),
  async (req, res) => {
    const { user_id, id, projectName } = req.body;

    const projectFound = await Project.findOne({
      _id: id,
      userId: user_id,
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Project not found!" });
    }

    await Project.updateOne(
      {
        _id: id,
      },
      {
        projectName,
      }
    );

    return res.status(200).json({ msg: "Project Name updated successfully!" });
  }
);

app.post(
  "/castings",
  ensureAuth,
  Validator(addCastingValidator, "body"),
  async (req, res) => {
    const {
      user_id,
      castName,
      concreteInformation,
      concreteSupplier,
      concreteType,
      portland,
      coarseAggregate,
      flyAsh,
      retardingMixture,
      water,
      fineAggregate,
      acceleratingAdmixture,
      concreteGrade,
      q,
      rt,
      su,
      k,
      m0,
      offset,
      remarks,
      advanceSetting,
    } = req.body;

    const projectFound = await Project.findOne({
      //   _id: id,
      userId: user_id,
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Project not found!" });
    }

    await Project.updateOne(
      {
        // _id: id,
        userId: user_id,
      },
      {
        $push: {
          castings: {
            castName,
            concreteInformation,
            ...(advanceSetting && concreteSupplier && { concreteSupplier }),
            ...(advanceSetting && concreteType && { concreteType }),
            ...(advanceSetting && portland && { portland }),
            ...(advanceSetting && coarseAggregate && { coarseAggregate }),
            ...(advanceSetting && flyAsh && { flyAsh }),
            ...(advanceSetting && retardingMixture && { retardingMixture }),
            ...(advanceSetting && water && { water }),
            ...(advanceSetting && fineAggregate && { fineAggregate }),
            ...(advanceSetting &&
              acceleratingAdmixture && { acceleratingAdmixture }),
            ...(advanceSetting && concreteGrade && { concreteGrade }),
            ...(advanceSetting && q && { q }),
            ...(advanceSetting && rt && { rt }),
            ...(advanceSetting && su && { su }),
            ...(advanceSetting && k && { k }),
            ...(advanceSetting && m0 && { m0 }),
            ...(advanceSetting && offset && { offset }),
            ...(remarks && { remarks }),
          },
        },
      }
    );

    return res.status(201).json({ msg: "Casting added successfully!" });
  }
);

app.put(
  "/castings",
  ensureAuth,
  Validator(updateCastingValidator, "body"),
  async (req, res) => {
    const {
      user_id,
      id,
      castName,
      concreteInformation,
      concreteSupplier,
      concreteType,
      portland,
      coarseAggregate,
      flyAsh,
      retardingMixture,
      water,
      fineAggregate,
      acceleratingAdmixture,
      concreteGrade,
      q,
      rt,
      su,
      k,
      m0,
      offset,
      remarks,
      advanceSetting,
    } = req.body;

    const projectFound = await Project.findOne({
      //   _id: id,
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: id,
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Casting not found!" });
    }

    await Project.updateOne(
      {
        // _id: id,
        userId: user_id,
        "castings._id": id,
      },
      {
        $set: {
          "castings.$.castName": castName,
          "castings.$.concreteInformation": concreteInformation,
          ...(advanceSetting &&
            concreteSupplier && {
              ["castings.$.concreteSupplier"]: concreteSupplier,
            }),
          ...(advanceSetting &&
            concreteType && { ["castings.$.concreteType"]: concreteType }),
          ...(advanceSetting &&
            portland && { ["castings.$.portland"]: portland }),
          ...(advanceSetting &&
            coarseAggregate && {
              ["castings.$.coarseAggregate"]: coarseAggregate,
            }),
          ...(advanceSetting && flyAsh && { ["castings.$.flyAsh"]: flyAsh }),
          ...(retardingMixture && {
            ["castings.$.retardingMixture"]: retardingMixture,
          }),
          ...(advanceSetting && water && { ["castings.$.water"]: water }),
          ...(advanceSetting &&
            fineAggregate && {
              ["castings.$.fineAggregate"]: fineAggregate,
            }),
          ...(advanceSetting &&
            acceleratingAdmixture && {
              ["castings.$.acceleratingAdmixture"]: acceleratingAdmixture,
            }),
          ...(advanceSetting &&
            concreteGrade && {
              ["castings.$.concreteGrade"]: concreteGrade,
            }),
          ...(advanceSetting && q && { ["castings.$.q"]: q }),
          ...(advanceSetting && rt && { ["castings.$.rt"]: rt }),
          ...(advanceSetting && su && { ["castings.$.su"]: su }),
          ...(advanceSetting && k && { ["castings.$.k"]: k }),
          ...(advanceSetting && m0 && { ["castings.$.m0"]: m0 }),
          ...(advanceSetting && offset && { ["castings.$.offset"]: offset }),
          ...(remarks && { ["castings.$.remarks"]: remarks }),
        },
      }
    );

    return res.status(200).json({ msg: "Casting updated successfully!" });
  }
);

app.get("/", ensureAuth, async (req, res) => {
  const { user_id } = req.body;

  const project = await Project.findOne({
    userId: user_id,
  });

  const castings = [],
    data = {};
  let castsCount = 0,
    devicesCount = 0;
  if (project) {
    data._id = project._id;
    data.userId = project.userId;
    data.projectName = project.projectName;

    castsCount = project.castings.length;
    if (project.castings.length) {
      project.castings.map((body) => {
        let devices = 0;

        if (body.structures.length) {
          body.structures.map((item) => {
            devices += item.devices.length;
          });
        }

        castings.push({
          _id: body._id,
          castName: body.castName,
          concreteInformation: body.concreteInformation,
          concreteSupplier: body.concreteSupplier || "",
          concreteType: body.concreteType || "",
          concreteGrade: body.concreteGrade || "",
          q: body.q || "",
          rt: body.rt || "",
          su: body.su || "",
          k: body.k || "",
          m0: body.m0 || "",
          offset: body.offset || "",
          portland: body?.portland || "",
          coarseAggregate: body?.coarseAggregate || "",
          flyAsh: body?.flyAsh || "",
          retardingMixture: body?.retardingMixture || "",
          water: body?.water || "",
          fineAggregate: body?.fineAggregate || "",
          acceleratingAdmixture: body?.acceleratingAdmixture || "",
          remarks: body?.remarks || "",
          structures: body.structures.length,
          devices,
        });
      });
    }
  }

  devicesCount = castings.reduce((acc, curr) => {
    return (acc += curr.devices);
  }, 0);

  return res
    .status(200)
    .json({ castsCount, devicesCount, project: { ...data, castings } });
});

app.delete(
  "/castings",
  ensureAuth,
  Validator(deleteCastingValidator, "query"),
  async (req, res) => {
    const { user_id } = req.body;
    const { id } = req.query;

    const projectFound = await Project.findOne({
      //   _id: id,
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: id,
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Casting not found!" });
    }

    await Project.updateOne(
      { userId: user_id },
      {
        $pull: {
          castings: { _id: id },
        },
      }
    );

    return res.status(200).json({ msg: "Deleted successfully!" });
  }
);

module.exports = app;
