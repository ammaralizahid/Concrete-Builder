const checkDataPoints = async (structures, dataPoints) => {
  let error = false;

  if (structures.length) {
    const notDoneStructures = structures.filter((item) => item.done === false);

    for (let index of dataPoints) {
      error = notDoneStructures.some((body) => {
        return body.devices.some((item) => {
          return item.dataPoints.some((ele) => {
            return +ele.dataPoint === +index.dataPoint;
          });
        });
      });

      if (error) {
        break;
      }
    }
  }

  return { error };
};

module.exports = { checkDataPoints };
