const Joi = require("joi");

module.exports.addStructureValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  castingId: Joi.string().required(),
  structure: Joi.string().required(),
  devices: Joi.array()
    .items(
      Joi.object({
        deviceId: Joi.string().required(),
        dataPoints: Joi.array()
          .items(
            Joi.object({
              dataPoint: Joi.string().valid(1, 2, 3, 4).required(),
              remarks: Joi.string(),
            }).required()
          )
          .required(),
      }).required()
    )
    .required(),
  targets: Joi.array()
    .items(
      Joi.object({
        name: Joi.string().required(),
        value: Joi.string().required(),
        unit: Joi.string().required(),
      }).required()
    )
    .required(),
  remarks: Joi.string(),
});

module.exports.updateStructureValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  castingId: Joi.string().required(),
  structureId: Joi.string().required(),
  structure: Joi.string().required(),
  devices: Joi.array()
    .items(
      Joi.object({
        deviceId: Joi.string().required(),
        dataPoints: Joi.array()
          .items(
            Joi.object({
              dataPoint: Joi.string().valid(1, 2, 3, 4).required(),
              remarks: Joi.string(),
            }).required()
          )
          .required(),
      }).required()
    )
    .required(),
  targets: Joi.array()
    .items(
      Joi.object({
        name: Joi.string().required(),
        value: Joi.string().required(),
        unit: Joi.string().required(),
      }).required()
    )
    .required(),
  remarks: Joi.string(),
  startMonitoringDate: Joi.date(),
  startMonitoringTime: Joi.string(),
  endMonitoringDate: Joi.date(),
  endMonitoringTime: Joi.string(),
});

module.exports.startStructureValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  castingId: Joi.string().required(),
  structureId: Joi.string().required(),
  startMonitoringDate: Joi.date().required(),
  startMonitoringTime: Joi.string().required(),
});

module.exports.endStructureValidator = Joi.object({
  user_id: Joi.string().required(),
  user_email: Joi.string().email().required(),
  castingId: Joi.string().required(),
  structureId: Joi.string().required(),
  endMonitoringDate: Joi.date().required(),
  endMonitoringTime: Joi.string().required(),
});

module.exports.deleteStructureValidator = Joi.object({
  castingId: Joi.string().required(),
  structureId: Joi.string().required(),
});
