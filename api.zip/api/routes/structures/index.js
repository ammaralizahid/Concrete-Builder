const express = require("express");

const { ensureAuth, Validator } = require("../../middleware/ensure-auth");
const User = require("../../models/users");
const Project = require("../../models/projects");
const {
  addStructureValidator,
  updateStructureValidator,
  startStructureValidator,
  endStructureValidator,
  deleteStructureValidator,
} = require("./validate");
const { checkDataPoints } = require("./helper");

const app = express.Router();

app.post(
  "/",
  ensureAuth,
  Validator(addStructureValidator, "body"),
  async (req, res) => {
    const { user_id, castingId, structure, devices, targets, remarks } =
      req.body;

    const projectFound = await Project.findOne({
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: castingId,
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Casting not found!" });
    }

    for (let index of devices) {
      const { error } = await checkDataPoints(
        projectFound.castings[0].structures,
        index.dataPoints
      );
      if (error) {
        return res.status(400).json({ msg: "Data Point already exists!" });
      }
    }

    await Project.updateOne(
      {
        userId: user_id,
        "castings._id": castingId,
      },
      {
        $push: {
          "castings.$.structures": {
            structure,
            devices,
            targets,
            ...(remarks && { remarks }),
          },
        },
      }
    );

    return res.status(201).json({ msg: "Structure added successfully!" });
  }
);

app.put(
  "/",
  ensureAuth,
  Validator(updateStructureValidator, "body"),
  async (req, res) => {
    const {
      user_id,
      castingId,
      structureId,
      structure,
      devices,
      targets,
      remarks,
      startMonitoringDate,
      startMonitoringTime,
      endMonitoringDate,
      endMonitoringTime,
    } = req.body;

    const projectFound = await Project.findOne({
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: castingId,
          structures: {
            $elemMatch: {
              _id: structureId,
            },
          },
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Structure not found!" });
    }

    const projectByCasting = await Project.findOne({
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: castingId,
          "structures._id": { $ne: structureId },
        },
      },
    });
    if (!projectByCasting) {
      return res.status(404).json({ msg: "Casting not found!" });
    }

    for (let index of devices) {
      const { error } = await checkDataPoints(
        projectByCasting.castings[0].structures,
        index.dataPoints
      );
      if (error) {
        return res.status(400).json({ msg: "Data Point already exists!" });
      }
    }

    await Project.updateOne(
      {
        userId: user_id,
        castings: {
          $elemMatch: {
            _id: castingId,
            "structures._id": structureId,
          },
        },
      },
      {
        $set: {
          ...(structure && {
            "castings.$[outer].structures.$[inner].structure": structure,
          }),
          ...(devices && {
            "castings.$[outer].structures.$[inner].devices": devices,
          }),
          ...(targets && {
            "castings.$[outer].structures.$[inner].targets": targets,
          }),
          ...(remarks && {
            "castings.$[outer].structures.$[inner].remarks": remarks,
          }),
          ...(startMonitoringDate && {
            "castings.$[outer].structures.$[inner].startMonitoringDate":
              startMonitoringDate,
          }),
          ...(startMonitoringTime && {
            "castings.$[outer].structures.$[inner].startMonitoringTime":
              startMonitoringTime,
          }),
          ...(endMonitoringDate && {
            "castings.$[outer].structures.$[inner].endMonitoringDate":
              endMonitoringDate,
          }),
          ...(endMonitoringTime && {
            "castings.$[outer].structures.$[inner].endMonitoringTime":
              endMonitoringTime,
          }),
        },
      },
      {
        arrayFilters: [
          { "outer._id": castingId },
          { "inner._id": structureId },
        ],
      }
    );

    return res.status(200).json({ msg: "Structure updated successfully!" });
  }
);

app.put(
  "/start",
  ensureAuth,
  Validator(startStructureValidator, "body"),
  async (req, res) => {
    const {
      user_id,
      castingId,
      structureId,
      startMonitoringDate,
      startMonitoringTime,
    } = req.body;

    const projectFound = await Project.findOne({
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: castingId,
          structures: {
            $elemMatch: {
              _id: structureId,
              done: false,
              startMonitoringDate: { $exists: false },
              startMonitoringTime: { $exists: false },
            },
          },
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Structure not found!" });
    }

    await Project.updateOne(
      {
        userId: user_id,
        castings: {
          $elemMatch: {
            _id: castingId,
            "structures._id": structureId,
          },
        },
      },
      {
        $set: {
          "castings.$[outer].structures.$[inner].startMonitoringDate":
            startMonitoringDate,
          "castings.$[outer].structures.$[inner].startMonitoringTime":
            startMonitoringTime,
        },
      },
      {
        arrayFilters: [
          { "outer._id": castingId },
          { "inner._id": structureId },
        ],
      }
    );

    return res.status(200).json({ msg: "Structure updated successfully!" });
  }
);

app.put(
  "/end",
  ensureAuth,
  Validator(endStructureValidator, "body"),
  async (req, res) => {
    const {
      user_id,
      castingId,
      structureId,
      endMonitoringDate,
      endMonitoringTime,
    } = req.body;

    const projectFound = await Project.findOne({
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: castingId,
          structures: {
            $elemMatch: {
              _id: structureId,
              done: false,
              endMonitoringDate: { $exists: false },
              endMonitoringTime: { $exists: false },
            },
          },
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Structure not found!" });
    }

    await Project.updateOne(
      {
        userId: user_id,
        castings: {
          $elemMatch: {
            _id: castingId,
            "structures._id": structureId,
          },
        },
      },
      {
        $set: {
          "castings.$[outer].structures.$[inner].endMonitoringDate":
            endMonitoringDate,
          "castings.$[outer].structures.$[inner].endMonitoringTime":
            endMonitoringTime,
          "castings.$[outer].structures.$[inner].done": true,
        },
      },
      {
        arrayFilters: [
          { "outer._id": castingId },
          { "inner._id": structureId },
        ],
      }
    );

    return res.status(200).json({ msg: "Structure updated successfully!" });
  }
);

app.get("/", ensureAuth, async (req, res) => {
  const { user_id } = req.body;
  const { castingId } = req.query;

  if (!castingId || castingId <= 0) {
    return res.status(403).send({ msg: "Invalid Casting Id!" });
  }

  const project = await Project.findOne({
    userId: user_id,
    castings: {
      $elemMatch: {
        _id: castingId,
      },
    },
  });

  let structures = [];
  if (project) {
    structures = project.castings[0].structures.map((body) => {
      return {
        _id: body._id,
        structure: body.structure,
        remarks: body.remarks,
        designStrength: project.castings[0].concreteGrade + " " + "MPa",
        done: body.done,
        startMonitoringDate: body.startMonitoringDate || "",
        startMonitoringTime: body.startMonitoringTime || "",
        endMonitoringDate: body.endMonitoringDate || "",
        endMonitoringTime: body.endMonitoringTime || "",
        devices: body.devices,
        targets: body.targets,
      };
    });
  }

  return res.status(200).json({ structures });
});

app.delete(
  "/",
  ensureAuth,
  Validator(deleteStructureValidator, "query"),
  async (req, res) => {
    const { user_id } = req.body;
    const { castingId, structureId } = req.query;

    const projectFound = await Project.findOne({
      userId: user_id,
      castings: {
        $elemMatch: {
          _id: castingId,
          structures: {
            $elemMatch: {
              _id: structureId,
            },
          },
        },
      },
    });
    if (!projectFound) {
      return res.status(404).json({ msg: "Structure not found!" });
    }

    await Project.updateOne(
      {
        userId: user_id,
        "castings._id": castingId,
      },
      {
        $pull: {
          "castings.$.structures": { _id: structureId },
        },
      }
    );

    return res.status(200).json({ msg: "Deleted successfully!" });
  }
);

module.exports = app;
